-- FiveM client for Bro, What’s the Number?
local Config = require 'config'

local isGameOpen = false

-- Export to open the minigame with custom rules
exports('OpenNumberGame', function(rules, cb)
    if isGameOpen then return end
    isGameOpen = true
    local settings = {
        codeLength = rules and rules.codeLength or Config.Defaults.codeLength,
        attempts = rules and rules.attempts or Config.Defaults.attempts,
        timer = rules and rules.timer or Config.Defaults.timer,
        allowLeadingZeros = rules and rules.allowLeadingZeros ~= nil and rules.allowLeadingZeros or Config.Defaults.allowLeadingZeros,
        allowedDigits = rules and rules.allowedDigits or Config.AllowedDigits,
        theme = rules and rules.theme or Config.Theme
    }
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', settings = settings })
    RegisterNUICallback('numberGameResult', function(data, cb2)
        SetNuiFocus(false, false)
        isGameOpen = false
        if cb then cb(data) end
        cb2('ok')
    end)
    RegisterNUICallback('closeNumberGame', function(_, cb2)
        SetNuiFocus(false, false)
        isGameOpen = false
        if cb then
            cb({ result = 'failed', reason = 'closed' })
        end
        cb2('ok')
    end)
end)
