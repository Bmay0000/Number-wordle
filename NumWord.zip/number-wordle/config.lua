-- Configurable rules for Bro, What’s the Number?
Config = {}

Config.Defaults = {
    codeLength = 5,         -- Number of digits in the code
    attempts = 6,           -- Number of guesses allowed
    timer = 120,            -- Time in seconds
    allowLeadingZeros = true
}

-- Add more rules as needed, e.g. allowed digits, themes, etc.
Config.AllowedDigits = "0123456789"
Config.Theme = "default"
